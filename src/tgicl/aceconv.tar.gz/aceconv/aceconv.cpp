//un/comment this for tracing options
//#define DBGTRACE 1
#include "AceParser.h"
#include "GArgs.h"
#include "GStr.h"
#include "GHash.hh"
#include "GList.hh"

#ifdef DBGTRACE
#include "GShMem.h"
#endif

#define usage "\
Converts an assembly (ace) file produced by cap3/cap4 into a file\n\
loadable by timmy. The unwanted gaps in the contigs are removed.\n\
Usage:\n\
 aceconv <ace_file> [-o <timmy_file>] [-f <fasta_file>] \n\
          [-p <prefix>] [-s <startnum>] [-b <db>] [-x <exon_file>][-B] \n\
 Options:\n\
 -o  : <timmy_file> to be written (if not given, stdout is used)\n\
 -f  : fasta file to write the contig sequences (with no gaps)\n\
 In both fasta file and the timmy file (com_name), the contigs will \n\
 be assigned unique identifiers (prefix + ordering number)\n\
 -p  : prefix to use for contig naming (default: original contig name)\n\
 -s  : the starting number to use in the contig name (default 1)\n\
 -b  : the db name to use for asmbl_link if no db is given within seq_name\n\
 -B  : don't parse (and don't remove) the seq id prefix\n\
 -x  : excise introns based on <exon_file>\n\
If <ace_file> is not given, it is expected at stdin\n\
"


class CSeg {
public:
  uint start;
  uint end;
  CSeg(uint s=0, uint e=0) {
    if (s<e) { start=s; end=e; }
        else { end=s; start=e; }
    }
  bool overlap(uint s, uint e) {
    if (s>e) { swap(s,e); }
     return start<s ? (s<=end) : (start<=e);
     }
  int length() { return end-start+1; }
  //comparison operators required for sorting
  bool operator==(CSeg& d){
      return (start==d.start && end==d.end);
      }
  bool operator>(CSeg& d){
     return (start==d.start)?(end>d.end):(start>d.start);
     }
  bool operator<(CSeg& d){
     return (start==d.start)?(end<d.end):(start<d.start);
     }
 CSeg& set(uint s, uint e) {
   if (s<e) { start=s; end=e; }
       else { end=s; start=e; }
    return *this;
    }
};

// -- global variables
bool parsePrefix=true;
FILE* ftimmy=NULL;
FILE* ffasta=NULL;
//GStr seq;
GStr default_db;
int lastContig=-1;
int* ctgrm=NULL; //store gap-shifting information for the current contig

int l_numstars=0;      //the number of stars found for last contig
int l_numseqs=0;       //number of sequences processed so far for the current contig
GStr l_ctgname; //contig name to assigned to the last found (current) contig

int startnum=1;
GStr prefix;

class CIntronLst:public GArray<CSeg> {
 public:
  uint ctgstart;
  uint ctgend;
  CIntronLst(uint cstart=0, uint cend=0):GArray<CSeg>(true,true) {
    ctgstart=cstart;
    ctgend=cend;
    }; //intron gaps loaded
};

GHash<CIntronLst> ctgis(true);

//current contig data loaded from exon file
CIntronLst* ctg_ilst=NULL;

// --- utility functions:
int loadIntrons(const char* fname, GHash<CIntronLst>& ctgs);
bool onSeqRead(int ctgno, LytCtgData* ctg, LytSeqInfo* seqnfo, char* s);
void writeTimmyCtg(char *ctgseq, LytCtgData* ctg);

void buildSeqName(LytSeqInfo* seqnfo, GStr& seqname);
void printCtgFasta(LytCtgData* ctg, char* ctgseq, int ctglen);
void writeTimmySeq(GStr& seqname, GStr& db, bool reversed, int newlen, GStr& ins, GStr& dels,
                   int new_start, int new_end, int clpR, int clpL, bool isLast);
//-------

//========================================================
//====================     main      =====================
//========================================================
int main(int argc, char * const argv[]) {
 GArgs args(argc, argv, "hGBf:x:o:p:s:b:");
 int e;
 if ((e=args.isError())>0)
    GError("%s\nInvalid argument: %s\n", usage, argv[e]);
 if (args.getOpt('h')!=NULL) GError("%s\n", usage);

 GStr infile;
 if (args.startNonOpt()) {
        infile=args.nextNonOpt();
        //GMessage("Ace file: %s\n",infile.chars());
        }
 parsePrefix=(args.getOpt('B')==NULL);
 GStr timmyfile = args.getOpt('o');
 GStr fastafile = args.getOpt('f');
 prefix= args.getOpt('p');
 //if (prefix.is_empty()) prefix="ASM";
 default_db= args.getOpt('b');
 GStr s=args.getOpt('s');
 if (!s.is_empty()) startnum=s.asInt();
 s=args.getOpt('x');
 if (!s.is_empty()) loadIntrons(s.chars(), ctgis);
 const char* acename= (infile.is_empty() || infile=="-") ? NULL : infile.chars();
 AceParser ace(acename);
 if (!ace.open())
   GError("Error opening ACE file '%s'\n", infile.chars());
 if (!timmyfile.is_empty()) {
   if (timmyfile=="-")
      ftimmy=stdout;
    else
     if ((ftimmy=fopen(timmyfile, "w"))==NULL)
       GError("Cannot write timmy file '%s'!\n", timmyfile.chars());
   }
 if (!fastafile.is_empty()) {
   if (fastafile=="-")
        ffasta=stdout;
      else
    if ((ffasta=fopen(fastafile, "w"))==NULL)
      GError("Cannot write timmy file '%s'!\n", fastafile.chars());
   }
 if (ffasta==NULL && ftimmy==NULL) ftimmy=stdout;
 ace.parse(&onSeqRead);
 GFREE(ctgrm);
 if (ftimmy!=stdout && ftimmy!=NULL) fclose(ftimmy);
 if (ffasta!=stdout && ffasta!=NULL) fclose(ffasta);
 //getc(stdin);
 //GMessage("*** all done ***\n");
}

void printCtgFasta(LytCtgData* ctg, char* ctgseq, int ctglen) {
   /*
   fprintf(ffasta, ">%s %d (%d seqs)\n", l_ctgname.chars(),
                ctglen, ctg->numseqs);*/
   fprintf(ffasta, ">%s\n", l_ctgname.chars());
   fflush(ffasta);
   int pos=0;
   while (pos<ctglen) {
     int wlen=60;
     if (pos+wlen>=ctglen) wlen=ctglen-pos;
     fwrite(ctgseq+pos, sizeof(char), wlen, ffasta);
     fwrite("\n", 1, 1, ffasta);
     pos+=60;
     }
}

void writeTimmyCtg(char *ctgseq, LytCtgData* ctg)   { //write timmy
  fprintf(ftimmy, "sequence\t%s\n", ctgseq);
  fprintf(ftimmy, "com_name\t%s\n", l_ctgname.chars());
  fprintf(ftimmy, "seq#\t%d\n", ctg->numseqs);
  fprintf(ftimmy, "method\tCAP3\ned_pn\tCAP3\ned_date\t7/7/1977\n");
  fflush(ftimmy);
  }

void writeTimmySeq(GStr& seqname, GStr &db, bool reversed, int newlen, GStr& ins, GStr& dels,
                   int new_start, int new_end, int clpR, int clpL, bool isLast) {
  fprintf(ftimmy, "\nseq_name\t%s\n", seqname.chars());
  if (ctg_ilst!=NULL) {
    new_start-=ctg_ilst->ctgstart-1;
    new_end-=ctg_ilst->ctgstart-1;
    }
  fprintf(ftimmy, "db\t%s\n",db.chars());
  if (ins.is_empty()) ins="|";
        else ins[0]='|';
  if (dels.is_empty()) dels="|";
        else dels[0]='|';
  fprintf(ftimmy, "comment\t%d%s%s\n", newlen, ins.chars(), dels.chars()); //this is needed for multi-stage assembly!
  fprintf(ftimmy, "asm_lend\t%d\n", new_start);
  fprintf(ftimmy, "asm_rend\t%d\n", new_end);
  if (reversed) {
      fprintf(ftimmy, "seq_lend\t%d\n", newlen-clpR);
      fprintf(ftimmy, "seq_rend\t%d\n", clpL+1);
      }
    else { //direct (+)
      fprintf(ftimmy, "seq_lend\t%d\n", clpL+1);
      fprintf(ftimmy, "seq_rend\t%d\n", newlen-clpR);
     }
  fprintf(ftimmy, "best\t0\n");
  fprintf(ftimmy, "offset\t%d\n", new_start-1);
  if (isLast) {
      fprintf(ftimmy, "|\n");
      l_numseqs=0;
      }
  fflush(ftimmy);
}

void buildSeqName(LytSeqInfo* seqnfo, GStr& seqname, GStr& db) {
if (parsePrefix) {
   db=seqnfo->name;
   seqname=db.split('|');
   if (seqname.is_empty()) {
        seqname=db;
        db=default_db;
        }
      else {
       db.lower();
       if (db=="np" || db=="p") db="preegad";
           else if (db=="et" || db=="ht") db="egad";
       }
   }
 else seqname=seqnfo->name;
}

//-----callback function for the parser - this is where all happens:
bool onSeqRead(int ctgno, LytCtgData* ctg, LytSeqInfo* seqnfo, char* s) {

 if (ctgno!=lastContig) { //new contig parsing
     GFREE(ctgrm);
     lastContig=ctgno;
     if (seqnfo!=NULL || s==NULL)
       GError("Error parsing contig %d data?(at contig %s, %dnt, %d seqs)\n",
            ctgno, ctg->len, ctg->name, ctg->numseqs);
     if (ctg->numseqs<2) return true;
     //reset ctg coverage coordinates
     ctg_ilst=NULL;
     //=== contig sequence cleaning/removing gaps:
    int len=strlen(s);
    char* ctgseq=NULL; //cleaned sequence will be here
    //retrieve intron info, if provided
    int ctg_ltrim=0;
    ctg_ilst=ctgis.Find(ctg->name);
    if (ctg_ilst!=NULL) {
      //"write" introns by overwriting bases with gaps
      for (int i=0;i<ctg_ilst->Count();i++) {
        CSeg& ig=ctg_ilst->Get(i);
        memset((void*)(s+ig.start-1),'*',ig.length());
        } //for each intron, "remove" bases from contig
      //GMessage("..setup contig %s introns:\n%s\n",ctg->name,s);
      int trimlen=ctg_ilst->ctgend-ctg_ilst->ctgstart+1;
      if (ctg_ilst->ctgstart<=0 || trimlen<10)
           GError("Error: wrong contig data in exons file for contig %s\n",
              ctg->name);
      ctg_ltrim=ctg_ilst->ctgstart-1;
      len=ctg_ilst->ctgend;
      s[len]=0;
      }
    l_numstars=0;
    l_numseqs=0;
    GMALLOC(ctgrm, (len+1)*sizeof(int));
    ctgrm[0]=0;
    for (int i=1;i<=len;i++) {
      l_numstars += ((s[i-1]=='*' || s[i-1]=='-')?1:0); //count the base gaps
      ctgrm[i]=l_numstars;
      }
    //ctgrm[len]=ctgrm[len-1];
    //now remove all the base gaps from the contig
    int ctglen=len - l_numstars;
    if (l_numstars>0) {
       GMALLOC(ctgseq, ctglen+1);
       int j=0;
       for (int i=0;i<=len;i++)
         if (s[i]!='*' && s[i]!='-') {
               ctgseq[j] = s[i];
               j++;
               }
       }
      else
       ctgseq=s;
     //now ctgseq contains the "good" sequence
     if (prefix.is_empty())
          l_ctgname=ctg->name;
         else
          l_ctgname.format("%s%d", prefix.chars(), startnum);

     startnum++;
     char* wseq=ctgseq+ctg_ltrim;
     ctglen-=ctg_ltrim;
     if (ffasta!=NULL) printCtgFasta(ctg, wseq, ctglen);
     if (ftimmy!=NULL) writeTimmyCtg(wseq, ctg);
     //-- no need to keep the contig sequence, we got the contig gaps positions
     if (ctgseq!=s) { GFREE(ctgseq); }
     return true;
     } //new contig parsing

 //==== from here: component sequence parsing in a contig
 if (seqnfo==NULL && l_numseqs==0)
      GError("Error parsing contig %d data?(last sequence fetched!) at contig %s, %dnt, %d seqs)\n",
            ctgno,  ctg->name, ctg->len, ctg->numseqs);

 if (s==NULL) GError("Error getting sequence %s data.\n", seqnfo->name);
 l_numseqs++;
 if (ftimmy==NULL || ctg->numseqs<2) return true;
 // process sequence information
 char * xs=seqnfo->expandGaps(s);
 int newlen=seqnfo->length();
 int clpL=seqnfo->left-1;
 int clpR=seqnfo->length()-seqnfo->right;
 int new_start=seqnfo->offs+clpL;
 int new_end=seqnfo->offs+seqnfo->length()-clpR-1;
 GStr dels;
 GStr ins;
 if (l_numstars>0) { //==============adjust coordinates
  new_start=new_start-ctgrm[new_start-1];
  new_end=new_end-ctgrm[new_end-1];
  //now create the cleaned copy of the sequence
  newlen=new_end-new_start+1+clpL+clpR;
  //parse the sequence to keep the position of gaps and indels
  int j=clpL;
  for (int i=clpL; i<seqnfo->length()-clpR; i++) {
      int ctgpos=seqnfo->offs+i;
      //delete if there was a '*' in the initial contig seq
      if (ctgrm[ctgpos]-ctgrm[ctgpos-1]==0) {
            if (xs[i]=='*') { // || xs[i]=='-') { //ins (gap) introduced by other reads
               //ins.appendfmt(",%d",j+1);
               }
            j++;
            }

          else { //deletion here
           if (xs[i]!='*' && xs[i]!='-') {
               //dels.appendfmt(",%d",j+1);
               }
           }
      } //for each base in this read
  } // eliminate propagated gaps
 if (s!=xs) GFREE(xs);
 //if (new_start<ctg_rmin) ctg_rmin=new_start;
 //if (new_end>ctg_rmax) ctg_rmax=new_end;
 bool isLastSeq=(ctg->numseqs==l_numseqs);
 GStr seqname;
 GStr db;
 buildSeqName(seqnfo, seqname, db);
 if (ftimmy!=NULL)
       writeTimmySeq(seqname, db, seqnfo->reversed, newlen, ins, dels,
                        new_start, new_end, clpR, clpL, isLastSeq);

 return true; //free parser memory
}

int inbuf_len=1024; //starting inbuf capacity
char* inbuf=NULL; // incoming buffer for sequence lines.

int loadIntrons(const char* fname, GHash<CIntronLst>& ctgs) {
 if (inbuf==NULL)  { GMALLOC(inbuf, inbuf_len); }

 FILE *f=fopen(fname, "rb");
 int n=0;
 if (f==NULL) GError("Error opening exon file: %s\n",fname);
 char* line;
 int llen=0;
 off_t fpos;
 while ((line=fgetline(inbuf, inbuf_len, f, &fpos, &llen))!=NULL) {
  if (strlen(line)<=1 || line[0]=='#') continue;
  //expected format: <CtgID> <exon_list>
  int idlen=strcspn(line,"\t ");
  char* p=line+idlen;
  char* exons=p;
  if (*line=='>') line++;
  *p=0;
  //ctg name is now at line
  CIntronLst* ilst=new CIntronLst();
  CSeg intron;
  uint v=0;
  uint prev_end=0;
  do {
     p++;
     parseUInt(p,v);
     if (ilst->ctgstart==0) ilst->ctgstart=v;
     if (prev_end>0) {
        ilst->Add(intron.set(prev_end+1,v-1));
        }
     if (*p!='-')
        GError("Error parsing exon list: %s %s\n", line, exons);
     p++;
     parseUInt(p,prev_end);
     while (*p==' ' || *p=='\t') p++;
     } while (*p==',');
    ilst->ctgend=prev_end;
    ctgis.Add(line,ilst);
    n++;
  } //while reading lines
 GFREE(inbuf);
 fclose(f);
 return n;
}

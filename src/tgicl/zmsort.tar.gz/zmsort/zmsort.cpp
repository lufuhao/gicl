//un/comment this for tracing options
//#define DBGTRACE 1
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include "GBase.h"
#include "GArgs.h"
#include "GStr.h"
#include "GList.hh"
#include <sys/stat.h>
#include <unistd.h>

#define usage "Usage: zmsort [-f<num>] [-r] [-n] [-d<delimiter>] \n\
                 [-C 'cmd'][-o <fbasename> [-s <zsize>] [-V]] files...\n\
 \n\
 Multi-way merge of sorted [and compressed] files. The input files\n\
 must be already sorted in the exact same order as given here and they\n\
 can be compressed. Optionally, the sorted output stream can be redirected\n\
 to a series of compressed files (if -o option is provided).\n\
 \n\
-f<num>         sort by the field number <num> (first field is 1);\n\
                if not given, the entire line is used \n\
-r              sort in reversed order (larger values first) \n\
-n              fields are compared as numeric values not as strings \n\
-C'<filtercmd>' also pipe sorted lines into command '<cmd>' and use\n\
                its output instead\n\
-d<delimiter>   use another field delimiter than tab\n\
-o<fbasename>   redirect output to gzip to compress it to series of \n\
                sequential files named <fbasename>_NNNN.Z\n\
-b              for -o option, use bzip2 with maximum compression instead\n\
                of gzip; output files will have a .bZ extension instead of .Z\n\
-s<zsize>       only for -o option: specify the approximate maximum size, \n\
                in MegaBytes, of each of the <fbasename>_NNNN.Z files \n\
                (default: 500)\n\
-V              verbose\n"


#define BUF_LEN 8192 //maximum input line length 
#define ERR_INVALID_PAIR "Invalid input line encountered:\n%s\n"

//============ global vars and structures:
bool is_numeric=false;
bool is_descending=false;
bool verbose=false;
bool use_bzip2=false;
int field_no=-1; /* whole line */
char delimiter[2]="\t";
GStr fbasename;
GStr midpipecmd; //-C command filter
int zmaxsize=500;
int partno=0;
GStr outcmd;

FILE* fout=NULL; /* this could be a popen handle */

class CLine {
public:
 int fileno;
 GStr line;
 GStr field; 
 int num;
 bool operator==(CLine& l){
     return (is_numeric)?(num==l.num):(field==l.field);
     }
   bool operator>(CLine& l){
     if (is_descending)
      return (is_numeric)?(num>l.num):(field>l.field);
     else 
      return (is_numeric)?(num<l.num):(field<l.field);
     }
   bool operator<(CLine& l){
     if (is_descending)
      return (is_numeric)?(num<l.num):(field<l.field);
     else 
      return (is_numeric)?(num>l.num):(field>l.field);
     }
   CLine(int fno, const char* s) {
     line=s;
     num=0;
     fileno=fno;
     int i=0;
     if (field_no>=0) {
       line.startTokenize(delimiter, tkFullString);
       while (i<=field_no && line.nextToken(field)) i++;
       }
       else field=line;
     //GMessage("field is '%s'\n",field.chars());
     if (is_numeric) num=field.asInt();
     }
};

GList<CLine> lines(true,true,false);

FILE** srcfiles;
char** fnames;

char* readLine(char* buf, int bufsize, int fno) {
 char* line=fgets(buf, bufsize-1, srcfiles[fno]); 
 if (line==NULL) return NULL;
 int l=strlen(line);
 if (line[l-1]!='\n' && l>=bufsize-2)
   GError("Input line too long (%d) from file '%s':\n%s\n", l,
      fnames[fno], line);
 line[l-1]='\0';     
 return line;
 }

/*void writeLine(const char* line, int& lno) {
 struct stat filestat;
 GStr partname;
 fprintf(fout, "%s\n", line);
 lno++;
 if (partno>0) { // we write into gzip's pipe 
   if ( lno%300 != 0 ) return; //only check every 300 lines
   partname.format("%s_%03d.Z", fbasename.chars(), partno);
   //fflush(stdout);sync();
   if ( stat(partname.chars(), &filestat)==0 ) {
      if (filestat.st_size>zmaxsize) {
         if (pclose(fout)==-1)
             GError("Error closing compressed writing pipe to '%s'\n",
                 partname.chars());         
         partno++;
        if (use_bzip2)
             outcmd.format("%sbzip2 -c9 > %s_%03d.bz2", midpipecmd.chars(),
                                                  fbasename.chars(), partno);
         else 
             outcmd.format("%sgzip -f > %s_%03d.Z", midpipecmd.chars(),
                                                    fbasename.chars(), partno);
         if ((fout=popen(outcmd.chars(), "w"))==NULL) {
           perror("popen()");
           GError("Error popen() to '%s'\n", outcmd.chars());
           }
         }
        }
       else if (lno>10000)
        GError("Error getting file size for '%s'\n",partname.chars());
    
   }
}
*/


void writeLine(const char* line, int& lno) {
 struct stat filestat;
 GStr partname;
 fprintf(fout, "%s\n", line);
 lno++;
 if (partno>0) { /* we write into gzip's pipe */
   if ( lno%300 != 0 ) return; //only check every 300 lines
   if (use_bzip2)
       partname.format("%s_%03d.bz2", fbasename.chars(), partno);
     else
       partname.format("%s_%03d.Z", fbasename.chars(), partno);
   //fflush(stdout);sync();
   if ( stat(partname.chars(), &filestat)==0 ) {
      if (filestat.st_size>zmaxsize) {
        if (pclose(fout)==-1)
             GError("Error closing compressed writing pipe to '%s'\n",
                 partname.chars());         
        partno++;
        lno=0;
        if (use_bzip2) {
             partname.format("%s_%03d.bz2", fbasename.chars(), partno);
             outcmd.format("%sbzip2 -c9 > %s", midpipecmd.chars(),
                                                           partname.chars());
             }
         else {
             partname.format("%s_%03d.Z", fbasename.chars(), partno);
             outcmd.format("%sgzip -f > %s", midpipecmd.chars(),
                                                    partname.chars());
             }
         if ((fout=popen(outcmd.chars(), "w"))==NULL) {
           perror("popen()");
           GError("Error popen() to '%s'\n", outcmd.chars());
           }
         }
        }
     else if (lno>10000)
        GError("Error getting file size for '%s'\n",partname.chars());
    
   }
}


//========================================================
//====================     main      =====================
//========================================================
int main(int argc, char * const argv[]) {
 char inbuf[BUF_LEN]; // incoming buffer for sequence lines.
 GArgs args(argc, argv, "hVbrno:s:f:d:");
 int e,i;
 if ((e=args.isError())>0)
    GError("%s\nInvalid argument: %s\n", usage, argv[e]);
 if (args.getOpt('h')!=NULL) GError("%s\n", usage);


 use_bzip2=(args.getOpt('b')!=NULL);
 is_numeric=(args.getOpt('n')!=NULL);
 is_descending=(args.getOpt('r')!=NULL);
 verbose=(args.getOpt('V')!=NULL);
 field_no=-1; /* whole line */
 GStr s=args.getOpt('f');
 if (!s.is_empty()) {
    field_no=s.asInt()-1;
    if (field_no<0) GError("Invalid field number provided.\n");
    }
 midpipecmd=args.getOpt('C');
 if (!midpipecmd.is_empty()) midpipecmd.append("| ");
 fbasename=args.getOpt('o');
 s=args.getOpt('s');
 if (!s.is_empty()) {
   if (fbasename.is_empty())
     GError("%s\n Option -s cannot be given without the -o option\n", usage);
   zmaxsize=s.asInt();
   if (zmaxsize<=0 || zmaxsize>2000)
    GError("%s\nInvalid compressed file size: %d MB (must be a pozitive number<2000)\n", 
            usage, zmaxsize);
   }
 zmaxsize = zmaxsize*1024*1024;
 int numfiles=args.startNonOpt();   
 if (numfiles==0)
    GError("No input files to process.\n");
 GMALLOC(srcfiles, sizeof(FILE*) * numfiles);
 GMALLOC(fnames, sizeof(char*) * numfiles);
 GStr cmd;
 //open all files
 for (i=0;i<numfiles;i++) {
  fnames[i]=(char*)args.nextNonOpt();
  GStr fname=fnames[i];
  //GMessage("Opening file '%s'\n", fname.chars());
  int dotidx=fname.rindex('.');
  if (dotidx>=0) dotidx-=fname.length();
  GStr ending=fname.substr(dotidx);
  ending.lower();
  if (ending==".z" || ending==".gz") {
    cmd.format("gzip -cd '%s'", fname.chars());
    if ((srcfiles[i]=popen(cmd.chars(), "r"))==NULL) {
        perror("popen()");
        GError("Error at popen('%s')\n", cmd.chars());
        }
    }
   else 
     if (ending==".bz" || ending==".bz2") {
      cmd.format("bzip2 -cd '%s'", fname.chars());
      if ((srcfiles[i]=popen(cmd.chars(), "r"))==NULL) {
         perror("popen()");
         GError("Error at popen('%s')\n", cmd.chars());
         }
      }
     else { //uncompressed files assumed
       if ((srcfiles[i]=fopen(fname.chars(), "r"))==NULL)
        GError("Error at fopen %s \n", fname.chars());
       }
  }
 
//- init: read the first lines from each file

for (i=0;i<numfiles; i++) {
 char* line=readLine(inbuf, BUF_LEN-1, i);
 //GMessage("%d: read: '%s'\n", i, line);
 if (line!=NULL)
   lines.Add(new CLine(i, line));
 }
/*
for (i=0;i<lines.Count();i++) {
 GMessage("%s\n", lines[i]->line.chars());
 }
GMessage("-----------------------\n"); 
*/
if (!fbasename.is_empty()) {
  partno++; //the first part is always 001
  if (use_bzip2)
      outcmd.format("%sbzip2 -c9 > %s_%03d.bz2", midpipecmd.chars(), fbasename.chars(), partno);
    else 
      outcmd.format("%sgzip -f > %s_%03d.Z", midpipecmd.chars(), fbasename.chars(), partno);
  if ((fout=popen(outcmd.chars(), "w"))==NULL) {
       perror("popen()");
       GError("Error popen() to '%s'\n", outcmd.chars());  
       }
  }
 else fout=stdout;

int last;
int lno=0;
while ((last=lines.Count())>0) {
  last--;
  CLine* best=lines[last]; // best hit, print it
  writeLine(best->line.chars(), lno);
  //read next one from this file
  int fno=best->fileno;
  char* line=readLine(inbuf, BUF_LEN-1, best->fileno);
  //GMessage("Removing line:'%s'\n", best->line.chars());
  lines.Delete(last); //never read from this file handle
  if (line!=NULL) {
    lines.Add(new CLine(fno, line));
    }
  }
if (verbose)
 GMessage("%d lines processed.\n", lno);
if (fout!=stdout) {
  if (pclose(fout)==-1)
         GError("Error closing compressed writing pipe to the last part (fbasename: '%s')\n",
                 fbasename.chars());
  if (verbose)               
   GMessage("Written %d compressed parts (base name: '%s')\n",
        partno, fbasename.chars());  
  }

//closing time:
for (i=0;i<numfiles; i++) {
  GStr fname=fnames[i];
  GStr ending=fname.substr(-2);
  if (ending==".z" || ending==".Z") 
     pclose(srcfiles[i]);
   else 
     fclose(srcfiles[i]);  
  }
 
 GFREE(srcfiles);
 GFREE(fnames);
} //-- end main()

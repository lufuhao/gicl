#define BUF_LEN 4096

#define SEED_LEN 4      /* don't forget to adjust this if you change SEED_T! */
#define SEED_T "TTTT"
#define SEED_A "AAAA"



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <pvm3.h>
#include "pvmsx.h"
/*#include "getopt.h"*/
#include <signal.h>

/*
  KNOWN PROBLEMS: 
    * on ctrl-c or pvm_halt the spawned tasks are still running!
    * pvm_kill() segfaults with no apparent reason :(
    so all spawned tasks will still run when the master dies (?!?)
  
  Assumption:
   - all the hosts working directories are all mounted such that  
     the master machine (running this program) can access them

  * The error protocol is plain and stupid (due to pvm api, as there is no way 
      to find out if a child task failed by checking the exit code):
    IF the slice file is present after a task exits, 
      THEN the task failed !
  * The working directory MUST be set by the psx program 
      by chdir to $PVMSX_WD !
 
*/   

#define USAGE  "Usage: \n\
pvmsx [-i infile] [-n numseq] [-s skipnum] [-t total] [-p procs]\n\
           [-d dir] [-C 'args'] -c executable\n\
\n\
-i infile   Name of file with seqs, default = (stdin)\n\
-n numseq   Number of seqs per iteration of executable, num_seq > 0  (1)\n\
-s skipnum  Skips skipnum sequences before sending to executable >= 0 (0)\n\
-t total    Total number of sequences to use from infile,  total > 0 (ALL)\n\
-p procs    Number of processes to spawn, 0 < procs <= 64 (1)\n\
             (better use the -m option)\n\
-m mfile    overrides -p option: file with one line for each CPU; \n\
            a line contains: a host machine name followed optionally \n\
            (after a space) by the working directory to use for that machine.\n\
            (to use multiple CPUs on a machine, provide the machine name again,\n\
            one different line)\n\
-d dir      Root name of working directories for each CPU(pvmsx)\n\
-C 'args'   Command line arguments to pass to executable\n\
-L          Enable logging (into file 'pvmsx.log')\n\
-c cmd      Name of the program or script which sx will call\n\
\n"

#define BUF_LEN 8192
#define TASK_DIED 777
#define MAX_NUMCPUS 256
#define MAX_NUMHOSTS 64
#define MAX_NUMARGS 64
#define MAX_NAMELEN 64
#define MAX_FAILURES 200

typedef struct CpuData {
 char* hostname;
 char* wrkdir; 
 char* fname; /* file name of the slice being processed */
 int seqcount; /* number of sequences in this slice */
 int slice_no; /* slice number */
 int hostid;
 int taskid;
 int retries;
 char used;
 } CpuData;
 
/* struct feature_t feat; current sequence data being analysed */

/* ================ global options/flags: */
char* infile=NULL; /* -i */
FILE *fin=NULL;
int  slicesize=1;  /* -n */
int  skipnum=0; /* -s */
int  maxseqs=0;   /* -t */
int  numprocs=1;  /* -p */
int  total_cpus=0;
char dir_root[256]; /* -d */
char cmdexec[256]; /* -c */
char useLog=0;    /* -L */
CpuData* failStack=NULL; /*stack storing failed jobs to be resubmitted */
int fstackSize=0;
FILE* flog=NULL;
char* hostfile=NULL;
char strbuf[BUF_LEN]; /* generic strbuf to use for various input operations*/
char lastLine[BUF_LEN]; /* buf to keep the previous line read */
int cur_seqno=0; /* current sequence number from input file (1-based) 
                    (the last seq in the last slice read) */
int slice_no=0;  /* current slice number (1-based)*/
int isLast=0;  /* was this slice the last one? */

char master_dir[1024]; /* the directory where pvmsx was started */

CpuData cpulist[MAX_NUMCPUS]; /* this is the list of hosts/directories, for each cpu */
char* cmdargv[MAX_NUMARGS]; /* max 64 arguments are allowed */

/* summary numbers: */
int smm_seqcount=0;
int smm_slicecount=0;

int pvm_started=0; /* set to 1 after the pvm was started successfully */
struct sigaction action;

void optErr(char opt);
void showUsage();
void setup_signals(void);
int parse_hostfile(char* fname, CpuData* lst);
/* returns total number of cpus! */
int parse_args(char* s, char** argv);
void errDie(const char* msg);
void errDie1(const char* msg, char* s);
void errDie2(const char* msg, char* s1, char* s2);
void spawnErr(int r, char* cmd, char* host);
int fileExists(char* dir, char* file);
int spawn_slicejob(CpuData* pcd);
void killtasks();

/* add a failed cpd entry to the failure stack; 
   cpd can be a direct pointer to an entry in cpulist,
   as the strings are duplicated entirely
*/
int fstackAdd(CpuData* cpd) {
 if (fstackSize>0) { 
     GREALLOC(failStack, (fstackSize+1)*sizeof(CpuData));
     }
    else {
     GMALLOC(failStack, sizeof(CpuData));
     }
 fstackSize++;
 if (fstackSize>MAX_FAILURES) {
    sprintf(strbuf, "Too many failures in the stack (%d). Aborting..\n", fstackSize);
    errDie(strbuf);
    }
 /* fill in new entry */
 failStack[fstackSize-1].hostname=strdup(cpd->hostname);
 failStack[fstackSize-1].wrkdir=strdup(cpd->wrkdir);
 failStack[fstackSize-1].fname=strdup(cpd->fname);
 failStack[fstackSize-1].seqcount=cpd->seqcount;
 failStack[fstackSize-1].slice_no=cpd->slice_no;
 failStack[fstackSize-1].retries=cpd->retries+1;
 if (failStack[fstackSize-1].retries>3) {
    sprintf(strbuf, "Too many retries (%d) for slice '%s'\n"
       "(last atempt was on host '%s', dir '%s'). Aborting..\n", 
         failStack[fstackSize-1].retries, cpd->fname, 
         cpd->hostname, cpd->wrkdir);
    errDie(strbuf);
    }
 failStack[fstackSize-1].taskid=cpd->taskid;
 failStack[fstackSize-1].hostid=cpd->hostid;
 return fstackSize;
 }

int fstackGet(CpuData* cpd, char* hostname) {
 /* remove a failure from the stack and fill cpd with its data
    cpd MUST NOT be a direct pointer to a cpulist[]  entry ,
    but a temp variable or so
    (the user is responsible for freeing the strings!)
    try to switch to a different host - so try to locate an entry in the stack
    which was not run on the same hostname when it failed.
   */
CpuData tmp;   
int k;
if (fstackSize<=0) return 0; /* no failures to re-run */
k=fstackSize-1;
while (k>=0 && strcmp(hostname, failStack[k].hostname)==0) k--;
if (k>=0 && k!=fstackSize-1) { /* found a better host */
   /* swap */
   memcpy(&tmp, &failStack[k], sizeof(CpuData));
   memcpy(&failStack[k], &failStack[fstackSize-1], sizeof(CpuData));
   memcpy(&failStack[fstackSize-1], &tmp, sizeof(CpuData));
   }
 k=fstackSize-1;
 /* copy the pointers, so no need to re-allocate the strings */
 cpd->hostname=failStack[k].hostname;
 cpd->wrkdir=failStack[k].wrkdir;
 cpd->fname=failStack[k].fname;
 cpd->slice_no=failStack[k].slice_no;
 cpd->seqcount=failStack[k].seqcount;
 cpd->retries=failStack[k].retries;
 cpd->taskid=failStack[k].taskid;
 /* shrink the failure stack */ 
 if (k==0) GFREE(failStack);
      else GREALLOC(failStack, k*sizeof(CpuData));
 fstackSize=k;
 return 1;
}


int getFastaSlice(FILE* f, CpuData* pcd, int* c);
/* reads next slice from f, setting the slice file name 
   in pdc->fname and the value of 1 if it is the last slice 
   set c to the number of sequences in this slice
   */

int cmpHostName(const void *p1, const void *p2) {
 char* n1=((CpuData*)p1)->hostname;
 char* n2=((CpuData*)p2)->hostname;
 return strcmp(n1,n2);
 }

int cmpTaskID(const void *p1, const void *p2) {
 int n1=((CpuData*)p1)->taskid;
 int n2=((CpuData*)p2)->taskid;
 return (n1>n2 ? 1 : ((n1==n2)?0:-1));
 }

void pvmXCheck(int r) {
 if (r<0) {
    pvm_perror("pvmsx");
    if (pvm_started) killtasks();
    if (useLog) fclose(flog);
    exit(1);
    }
 }
 
int main(int argc, char * const argv[]) {
  CpuData cpud, *pcpud; 
  char *s;
  int c,i,r;
  int running=0;
  int failed=0;
  int num_hosts=0;
  int cmdargc=0;
  /* 
  struct pvmhostinfo hostinfo;
  struct pvmhostinfo* phostinfo=&hostinfo; 
  int tid;
  */
  for (i=0;i<7;i++) 
     cmdargv[i]=NULL;
  cmdexec[0]='\0';
  lastLine[0]='\0';
  strcpy(dir_root, "pvmsx");
  if (getcwd(master_dir, 1023)==NULL)
    errDie("Error at getcwd(). Path too long?\n");
  while ((c=getopt(argc, argv, "hLm:c:C:i:n:s:t:p:d:")) > 0) {
     switch (c) {         
        case 'm': hostfile=optarg;
                  break;
        case 'c': strcpy(cmdexec,optarg);
                  if (cmdexec[0]=='\0') 
                       optErr('c');
                  break;
        case 'L': useLog=1;
                  if ((flog=fopen("pvmsx.log", "w"))==NULL) {
                      fprintf(stderr,"Error trying to open log file 'pvmsx.log' for write!\n");
                      optErr('L');
                      }
                  break;
        case 'C': cmdargc=parse_args(optarg, cmdargv);
                  break;
        case 'i': if ((fin=fopen(optarg, "r"))==NULL) {
                         fprintf(stderr,"Error opening sequence file '%s'.\n", optarg);
                         optErr('i');
                         }
                  infile=strdup(optarg);       
                  break;
        case 'n': slicesize=strtol(optarg, (char **)NULL, 10);
                  if (slicesize<=0) optErr('n');
                  break;
        case 's': skipnum=strtol(optarg, (char **)NULL, 10);
                  if (skipnum<0) optErr('s');
                  break;
        case 't': maxseqs=strtol(optarg, (char **)NULL, 10);
                  if (maxseqs<0) optErr('t');
                  break;
        case 'p': numprocs=strtol(optarg, (char **)NULL, 10);
                  if (numprocs<1 || total_cpus>0) optErr('p');
                  break;
        case 'd': strcpy(dir_root, optarg);
                  break;
        case 'h': showUsage();exit(1);
       }
  } /* while options */
  if (*cmdexec=='\0') optErr('c');
  if (fin==NULL)
         fin=stdin;
  if (hostfile!=NULL) {
     total_cpus=parse_hostfile(hostfile, cpulist);
     if (total_cpus<=0) optErr('m');
     }
   else { /* dumb mode, use the local host only ! */
      total_cpus=numprocs;
      for (i=0;i<total_cpus;i++) {
       cpulist[i].hostname=strdup(getenv("HOST"));

       sprintf(strbuf, "%s/%s_%d",master_dir, dir_root, i+1);

       cpulist[i].wrkdir=strdup(strbuf);
       cpulist[i].taskid =  -1;
       cpulist[i].hostid =  -1;
       cpulist[i].seqcount=0;
       cpulist[i].slice_no=0;
       cpulist[i].retries=0;
       cpulist[i].fname = NULL;
       cpulist[i].used=0;
       }
      }
  /* sort the cpulist by hostname */
  qsort(cpulist, total_cpus, sizeof(CpuData), &cmpHostName); 
  if (useLog) {
    for (i=0;i<total_cpus;i++) {
       fprintf(flog, "CPU %d: host '%s', working directory '%s'\n",
          i+1, cpulist[i].hostname, cpulist[i].wrkdir);
      }
    fflush(flog);
    }
  /* === be sure to start the pvm */
  setup_signals();
  r=system("echo quit | pvm 2>&1 >/dev/null");
  /* parameters are not really explained for this call:
  r=pvm_start_pvmd(0, NULL, 1); */
  if (r!=0)
     errDie1("Error trying to start pvmd. Is '%s' a pvm ?!?\n", getenv("HOST"));
  pvm_started=1;   
  /* ==== add the hosts from the list ==== */  
  num_hosts=0;
  s=NULL;
  for (i=0;i<total_cpus;i++) {
    if (s!=NULL && strcmp(s,cpulist[i].hostname)==0) continue;
    s=cpulist[i].hostname;
    r=pvm_addhosts(&cpulist[i].hostname, 1, &c);
    if (c<0) {
      if (c==PvmDupHost) {
          if (strcmp(getenv("HOST"), cpulist[i].hostname)) {
             sprintf(strbuf,"Warning: host '%s' is already added to the pvm.\n",
                  cpulist[i].hostname); 
             fprintf(stderr, "%s",strbuf);
              if (useLog)
               fprintf(flog, "%s", strbuf);
             }
          }
        else {
          fprintf(stderr, " - pvm error code: %d\n", c);
          errDie1("Error: cannot add host '%s' to the pvm !\n",
             cpulist[i].hostname);
          }
      }
    num_hosts++;
    }
  if (useLog)  
    fprintf(flog,"Using %d hosts (total of %d CPUs)\n", num_hosts, total_cpus);
    
  /* ============= START submitting jobs ============= */;     
  /* setenv("PVM_EXPORT", "PATH:LD_LIBRARY_PATH:PERLLIB:PVMSX_WD:HOME", 1);*/
  if (putenv("PVM_EXPORT=PATH:LD_LIBRARY_PATH:PERLLIB:PVMSX_WD:HOME")) 
    errDie("Error: failed at setting PVM_EXPORT environment variable!\n");    
  running=0;
  for (i=0;i<total_cpus;i++) {
   isLast=getFastaSlice(fin, &cpulist[i], &c);
   if (isLast && c==0)       
       break; /* premature end of file */
   /* fill cmdargv with all psx data: */
   slice_no++;
   cur_seqno+=c;
   GFREE(cmdargv[0]);
   cmdargv[0] = strdup(cpulist[i].fname);
   cpulist[i].seqcount=c;
   cpulist[i].slice_no=slice_no;
   cpulist[i].retries=0;
   spawn_slicejob(&cpulist[i]);
   running++;
   if (isLast) break;
   }
 /*======= now wait for notifications =====*/
 while (running) {
  qsort(cpulist, total_cpus, sizeof(CpuData), &cmpTaskID);
  pvmXCheck(pvm_recv(-1, TASK_DIED));
  pvmXCheck(pvm_upkint(&c, 1, 1));
  /* locate the cpudata for this taskid */
  cpud.taskid=c;
  pcpud=NULL;
  pcpud=bsearch(&cpud, cpulist, total_cpus, 
            sizeof(CpuData), &cmpTaskID);
  if (pcpud==NULL) {
       sprintf(strbuf, "Error: returned taskid %d not found.\n", c);
       errDie(strbuf);
       }
  /*     
  if (useLog) {
   fprintf(flog, "  <- Finished task %d on host '%s'(slice: '%s') in %s\n",
             pcpud->taskid, pcpud->hostname, pcpud->fname, pcpud->wrkdir);
   fflush(flog);
   } */
             
  /* check if it was successful by checking if the file is still there !*/
  failed=0;
  if (fileExists(pcpud->wrkdir, pcpud->fname)) {
       /* ooops, something was wrong, slice's still there */
       /* Is the host still responding? */
       failed=1;
       sprintf(strbuf, "Warning: task %d, slice '%s', failed on host '%s' in %s\n",
             pcpud->taskid, pcpud->fname, pcpud->hostname, pcpud->wrkdir);
       fprintf(stderr, "%s", strbuf);
       if (useLog) fprintf(flog, "%s", strbuf);
       fstackAdd(pcpud); /* failed, put this on failure stack now */       
       if (pvm_mstat(pcpud->hostname)!=PvmOk) {
         sprintf(strbuf, "Host '%s' doesn't seem to respond. Removing it from the pvm.\n",
               pcpud->hostname);
         fprintf(stderr, "%s", strbuf);
         if (useLog) fprintf(flog, "%s", strbuf);
         /* remove this host from the list of available ones 
            it will never send notifications, so we don't really care */
         pvm_delhosts(&pcpud->hostname, 1, &c);
         pcpud->taskid=-1;
         pcpud->used=-1;
         running--;
         continue; /* can't assign a new job to this cpu, so skip the rest of the loop */
         }
       } /* task failed - slice file was still there */
     else { /* assumed slice was processed ok */
       smm_seqcount+=pcpud->seqcount;
       smm_slicecount=pcpud->slice_no;
       }
  /* so pcpud is now available for another slice job */
  if (fstackGet(&cpud, pcpud->hostname)) {
    /* pick up a previously failed job to rerun it */
    if (strcmp(cpud.wrkdir, pcpud->wrkdir)!=0) {
       sprintf(strbuf, "%s/%s", cpud.wrkdir, cpud.fname);
       if (rename(strbuf, pcpud->wrkdir)!=0)
          errDie2("Error moving file '%s' to '%s'", strbuf, pcpud->wrkdir);
       }
    GFREE(pcpud->fname);
    pcpud->fname=cpud.fname;
    pcpud->slice_no=cpud.slice_no;
    pcpud->seqcount=cpud.seqcount;
    pcpud->retries=cpud.retries;
    spawn_slicejob(pcpud);
    sprintf(strbuf, " Retry no. %d for slice '%s'on host '%s' in %s (task id: %d)\n",
        cpud.retries, pcpud->fname, pcpud->hostname, pcpud->wrkdir, pcpud->taskid);
    if (useLog) { fprintf(flog, "%s",strbuf); fflush(flog); }
    fprintf(stderr, "%s",strbuf);
    continue; /* pcpud re-used, so there is nothing to do but wait */
    }
  else  
  /* -= at this point, there is nothing in the failure stack =- */  
    if (isLast==0) { /* get the next slice, if any, from the db file */
      isLast=getFastaSlice(fin, pcpud, &c);
      slice_no++;
      cur_seqno+=c;
      pcpud->seqcount=c;
      pcpud->slice_no=slice_no;
      pcpud->retries=0;
      spawn_slicejob(pcpud);
      continue; /* pcpud reused */
      }
  /* at this point, there is no use for this just freed CPU */    
  running--;
  pcpud->taskid=-1;
  pcpud->used=0;
  }
 
/* if ((fout=fopen(outfile,"w"))==NULL) optErr('o'); */
/* if (do_write) fclose(fout); */

if (useLog) {
  fprintf(flog, "Total of %d sequences (%d slices) were processed.\n", 
            smm_seqcount, smm_slicecount);
  fclose(flog);
  }
if (fin!=stdin) fclose(fin);
return 0;
}


/*********************************************************************/
/*                        Helper functions                           */
/*********************************************************************/

void optErr(char opt) {
 showUsage();
 fprintf(stderr, "\nIncorrect value specified for -%c option!\n", opt);
 exit(1);
}

void errDie(const char* msg) {
 fprintf(stderr, "\n%s\n", msg);
 if (useLog) {
   fprintf(flog,"\n%s\n", msg);
   fclose(flog);
   }
 if (pvm_started) {
   fprintf(stderr,"Halting the pvm.\n");
   killtasks();
   }
 exit(1);
}

void errDie1(const char* msg, char* s) {
 fprintf(stderr, msg, s);
 if (useLog) {
   fprintf(flog, msg, s);
   fclose(flog);
   }
 if (pvm_started) killtasks();
 exit(1);
}

void errDie2(const char* msg, char* s1, char* s2) {
 fprintf(stderr, msg, s1, s2);
 if (useLog) {
   fprintf(flog, msg, s1,s2);
   fclose(flog);
   }
 if (pvm_started) killtasks();
 exit(1);
}

void showUsage() {
 fprintf(stderr, USAGE);
}


//rindex function is missing on some platforms ?
char* rstrchr(char* str, char ch) {  /* returns a pointer to the rightmost
  occurence of ch in str  */
 char *p;
 if (str==NULL) return NULL;
 p=str+strlen(str)-1;
 while (p>=str) {
    if (*p==ch) return p;
    p--;
    }
 return NULL;
 }


/* expects data to already be prepared in the cpulist[i] structures */
int spawn_slicejob(CpuData* cpd) {
 int r;
 GFREE(cmdargv[0]);
 cmdargv[0] = strdup(cpd->fname);
 GFREE(cmdargv[1]);sprintf(strbuf, "%d", cpd->seqcount);
 cmdargv[1]=strdup(strbuf);
 GFREE(cmdargv[2]);sprintf(strbuf, "%d", cpd->slice_no);
 cmdargv[2]=strdup(strbuf);
 GFREE(cmdargv[3]);sprintf(strbuf, "%d", isLast);
 cmdargv[3]=strdup(strbuf);
 if (cmdargv[4]==NULL) { /* only set first time */
    sprintf(strbuf, "%d", skipnum);
    cmdargv[4]=strdup(strbuf);
    sprintf(strbuf, "%d", maxseqs);
    cmdargv[5]=strdup(strbuf);
    }
 /* fprintf(stderr, "Submitting job %d ('%s') on host '%s'\n",
              i+1, cmdexec, cpd->hostname); */              
 if (cpd->wrkdir!=NULL) {
      /* setenv("PVMSX_WD", cpd->wrkdir, 1); */
     sprintf(strbuf, "PVMSX_WD=%s", cpd->wrkdir);
     if (putenv(strbuf)) 
       errDie("Error: failed at setting PVMSX_WD environment variable!\n");    
      }
 r=pvm_spawn(cmdexec, cmdargv, PvmTaskHost, 
       cpd->hostname, 1, &(cpd->taskid));
 if (r<1) {
     if (r<0) {
        pvm_perror("spawn");
        if (pvm_started) killtasks();
        exit(1);
        }
     spawnErr(cpd->taskid, cmdexec, cpd->hostname);
     }
  else /*
    if (useLog) {
     fprintf(flog, "> === STARTed task %d on host '%s' (slice: '%s') in %s\n",
                   cpd->taskid, cpd->hostname, cpd->fname, cpd->wrkdir);
     fflush(flog);
     }
     */
  cpd->used=1;
  r=pvm_notify(PvmTaskExit, TASK_DIED, 1, &(cpd->taskid));
  pvmXCheck(r);
  return 0;
}

int parse_hostfile(char* fname, CpuData* cpulst) {
 char* host; 
 char* wrkdir;
 char *s, *domain;
 int c,l;
 int cpucount=0;
 FILE* fh=fopen(fname, "r");
 s=getenv("HOST");
 domain=strchr(s, '.');
 if (fh==NULL)
   errDie("Error opening the host file.");
 wrkdir=NULL;
 while ((s=fgets(strbuf, BUF_LEN-1,fh))!=NULL) {
    l=strlen(s);
    if (s[l-1]!='\n')
       errDie1("Error: line too long in hostfile:\n%s",s);
    if (l<2) continue;
    s[l-1]='\0';
    host=s;
    wrkdir=NULL;
    c=strcspn(host," \t:");
    if (c<l) {
      host[c]='\0';
      wrkdir=s+c+1;
      while (*wrkdir==' ' || *wrkdir=='\t') wrkdir++;
      }
    if (domain!=NULL && strchr(host, '.')==NULL) {
      cpulst[cpucount].hostname=(char*)malloc(strlen(host)+strlen(domain)+1);
      strcpy(cpulst[cpucount].hostname, host);
      strcat(cpulst[cpucount].hostname, domain);
      }
     else
       cpulst[cpucount].hostname=strdup(host);
    if (*wrkdir=='\0') {
       sprintf(strbuf, "%s/%s_%d",master_dir, dir_root, cpucount+1);
       cpulst[cpucount].wrkdir=strdup(strbuf);
       }
      else {
       if (*wrkdir=='/')
           cpulst[cpucount].wrkdir = strdup(wrkdir);
         else { /* relative path not to be used as such */
           /* fprintf(stderr, "use relative path '%s' to '%s'\n", wrkdir, master_dir); */
           sprintf(strbuf, "%s/%s", master_dir, wrkdir);
           cpulst[cpucount].wrkdir = strdup(strbuf);
           }
       }
    cpulst[cpucount].taskid =  -1;
    cpulst[cpucount].hostid =  -1;
    cpulst[cpucount].used=0;
    cpulst[cpucount].seqcount=0;
    cpulst[cpucount].slice_no=0;
    cpulst[cpucount].retries=0;
    cpulst[cpucount].fname=NULL;
    cpucount++;
    }
fclose(fh);
return cpucount;
}

int parse_args(char* s, char** argv) {
 /* right now, only use spaces, don't care about enclosed strings */
 char* p;
 int numargs=0;
 while ((p=strchr(s, ' '))!=NULL) {
   *p='\0';
   if (*s!='\0') {
     argv[numargs+6]=strdup(s);
     numargs++;
     }
   p++;
   while (isspace(*p) && *p!='\0') p++;
   s=p;
   }
 if (*s!='\0') {
   argv[numargs+6]=strdup(s);
   numargs++;
   }
 argv[numargs+6]=NULL;
 return numargs;
}

void spawnErr(int r, char* cmd, char* host) {
 if (r>=0) return;
 if (r==PvmBadParam) 
    sprintf(strbuf, "Error: Bad parameter for spawn (on '%s')\n", host);
 else 
  if (r==PvmNoHost)
    sprintf(strbuf, "Error: bad host '%s' specified (not a vm?)\n", host);
 else 
  if (r==PvmNoFile)
    sprintf(strbuf, "Error: executable '%s' not found in path on '%s'\n", 
                   cmd, host);
 else 
  if (r==PvmNoMem)
    sprintf(strbuf, "Error: malloc failed (no memory on host '%s')\n",host);
 else   
  if (r==PvmSysErr)
    sprintf(strbuf, "Error: pvmd not responding at spawn on  host '%s'\n",host);
 else    
  if (r==PvmOutOfRes)
    sprintf(strbuf, "Error: out of resources at spawn on  host '%s'\n",host); 
 else   
   sprintf(strbuf, "Error: [undetermined cause] at spawn on  host '%s'\n",host); 
 /* pvm_exit(); */
 if (useLog) fprintf(flog, "%s", strbuf);
 fprintf(stderr, "%s", strbuf);
 if (pvm_started) killtasks();
 exit(1);  
}


int getFastaSlice(FILE* f, CpuData* pcd, int* c) {
/* reads next slice from f, setting the slice file name 
   in pdc->fname and the value of 1 if it is the last slice 
   c must be set to the number of sequences written in this slice 
   file
   */
int i=-1;
FILE* fslice;
int deflw=0; /* deflines written */
char* s;
int l=0;
*c=0;
GFREE(pcd->fname);
if (slice_no==0 && skipnum>0) { /* first time skipping */
  i=0;
  while ((s=fgets(strbuf, BUF_LEN-1, fin))!=NULL) {
    if (s[0]=='>') i++;
    if (i>skipnum) {
       strcpy(lastLine, strbuf);
       break;
       }
    l=strlen(strbuf);
    if (s[l-1]!='\n') {
      while ((s=fgets(strbuf, BUF_LEN-1, fin))!=NULL && s[strlen(s)-1]!='\n') ;
      }
    }
  if (s==NULL)
     return 1; /* end of file reached */
  }
/* open the slice file for write */
if (chdir(pcd->wrkdir)!=0) {
  if (mkdir(pcd->wrkdir, 0775)!=0)
     errDie1("Error creating directory '%s'", pcd->wrkdir);
  if (chdir(pcd->wrkdir)!=0)
     errDie1("Error changing directory to: '%s'",pcd->wrkdir);
  }
/* never overwrite an existing file: */
i=-1;
s=rstrchr(infile, '/');
if (s!=NULL) s++;
     else s=infile;
do {
  i++;
  sprintf(strbuf, "%s_@%d_v%d.%d", s, cur_seqno+1+skipnum, i, slice_no+1);
  } while (fileExists(pcd->wrkdir, strbuf));
if ((fslice=fopen(strbuf, "w"))==NULL) {
  fprintf(stderr, "Error: failed to create file '%s'\nin directory '%s'\n",
        strbuf, pcd->wrkdir);
  exit(1);
  }
deflw=0;  
pcd->fname=strdup(strbuf);
if (lastLine[0]=='>') {
   fprintf(fslice, "%s", lastLine);
   deflw=1;
   if (lastLine[strlen(lastLine)-1]!='\n') { /* incomplete defline, finish it */
     while ((s=fgets(strbuf, BUF_LEN-1, fin))!=NULL && s[strlen(s)-1]!='\n') 
       fprintf(fslice, "%s", s);
     }
  }
lastLine[0]='\0';
while ((s=fgets(strbuf, BUF_LEN-1, fin))!=NULL) {
  if (s[0]=='>') {
        *c += deflw;
        if (*c==slicesize) {
           strcpy(lastLine, strbuf);
           break;
           }
        if (maxseqs>0 && *c+cur_seqno>=maxseqs) {
           s=NULL;
           deflw=0;
           break; /* last */
           }
        deflw=1;
        }
  do {
   fprintf(fslice, "%s", s);
   l=strlen(s);
   } while (s[l-1]!='\n' && (s=fgets(strbuf, BUF_LEN-1, fin))!=NULL);
  if (s==NULL) break;
  }
if (s==NULL) *c+= deflw;
fflush(fslice);fclose(fslice);
if (chdir(master_dir)!=0)
    errDie1("Error chdir() back to master directory from '%s'", pcd->wrkdir);
return (s==NULL)?1:0;
}

void GError(const char* s) {
  fprintf(stderr, "%s\n",s);
  fflush(stderr);
  if (pvm_started) killtasks();
  exit(1);
}

int fileExists(char* dir, char* file) {
 FILE* ftest;
 char testbuf[2048];
 sprintf(testbuf, "%s/%s", dir, file);
 if ((ftest=fopen(testbuf, "r"))!=NULL) {
   fclose(ftest);
   return 1;
   }
 else {
   return 0;  
   }

}

int GMalloc(pointer* ptr,unsigned long size){
  if (size!=0) *ptr=malloc(size);
  return (*ptr!=NULL)?1:0;
  }
  
/* Allocate cleaned memory (0 filled) */
int GCalloc(pointer* ptr,unsigned long size){
  *ptr=calloc(size,1);
  return (*ptr!=NULL)?1:0;
  }

/*  Resize memory */
int GRealloc(pointer* ptr, unsigned long size) {
  pointer p=NULL;
  if (size==0) {
    GFree(ptr);
    return 1;
    }  
  p=realloc(*ptr,size);
  if (p!=NULL) {
      *ptr=p;
      return 1;
      }
  return 0;
  }

/* Free memory, resets ptr to NULL afterward */
void GFree(pointer* ptr) {
  if (*ptr) free(*ptr);
  *ptr=NULL;
  }

void sig_handler(int signum) {
 if (signum==SIGABRT || signum==SIGINT) {
   errDie("pvmsx: signal caught.");
   }
 }

void killtasks() {
 int i;
 if (pvm_started!=1) return;
 for (i=0;i<total_cpus;i++) 
   if (cpulist[i].used==1 && cpulist[i].taskid>0) {
     /* fprintf(stderr, "killing task %d\n", cpulist[i].taskid);
        pvm_kill(cpulist[i].taskid); 
     stupid thing, it crashes my program.   
        */
     }
 pvm_halt();
 /* pvm_exit(); this one crashes too.. */
}
 
void err_quit(const char* s) {
 perror(s);
 exit(1);
 }


 
void setup_signals(void) {
 action.sa_handler = sig_handler;
 sigemptyset(&action.sa_mask);
 action.sa_flags=SA_NOCLDSTOP;
 if ((sigaction(SIGABRT, &action, NULL))<0) err_quit("sigaction SIGABRT");
 if ((sigaction(SIGINT, &action, NULL))<0) err_quit("sigaction SIGQUIT");
 }
 

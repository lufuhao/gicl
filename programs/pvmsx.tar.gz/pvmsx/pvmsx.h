#ifndef PVMTEST_H_
#define PVMTEST_H_

void GError(const char* s);

typedef void* pointer;

#define ERR_ALLOC "\nError allocating memory!\n"

int GMalloc(pointer* ptr, unsigned long size); /* Allocate memory */
int GCalloc(pointer* ptr, unsigned long size); /* Allocate and initialize memory*/
int GRealloc(pointer* ptr,unsigned long size); /* Resize memory */
void GFree(pointer* ptr); /* Free memory, resets ptr to NULL */

#define GMALLOC(ptr,size)  if (!GMalloc((pointer*)(&ptr),size)) GError(ERR_ALLOC)
#define GCALLOC(ptr,size)  if (!GCalloc((pointer*)(&ptr),size)) GError(ERR_ALLOC)
#define GREALLOC(ptr,size) if (!GRealloc((pointer*)(&ptr),size)) GError(ERR_ALLOC)
#define GFREE(ptr)       GFree((pointer*)(&ptr))


#endif

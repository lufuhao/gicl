#define MaxChainNum 100
#define MaxEntryNum 10000
#ifndef PATH_MAX
#define PATH_MAX  1020
#endif
